import java.io.*;

public class Translator {
    private Lexer lex;
    private BufferedReader pbr;
    private Token look;
    
    SymbolTable st = new SymbolTable();
    CodeGenerator code = new CodeGenerator();
    int count=0;

    public Translator(Lexer l, BufferedReader br) {
        lex = l;
        pbr = br;
        move();
    }

    void move() { 
        look = lex.lexical_scan(pbr);
        System.out.println("token = " + look);
    }

    void error(String s) { 
        throw new Error("near line " + lex.line + ": " + s);
    }

    void match(int t) {
        if (look.tag == t) {
            if (look.tag != Tag.EOF) move();
        } else error("syntax error");
    }

    public void prog() {        
        switch(look.tag){
            case Tag.ASSIGN:
            case Tag.PRINT:
            case Tag.READ:
            case Tag.WHILE:
            case Tag.IF:
            case '{':
                int lnext_prog = code.newLabel();
                statlist(lnext_prog);
                code.emitLabel(lnext_prog); 
                match(Tag.EOF);
                try {
                    code.toJasmin();
                }
                catch(java.io.IOException e) {
                    System.out.println("IO error\n");
                };
                break;
            default:
                error("prog");
        }
        
    }

     
     public void statlist(int lnext_statlist){
         int new_label;
        switch(look.tag){
            case Tag.ASSIGN:
            case Tag.PRINT:
            case Tag.READ:
            case Tag.WHILE:
            case Tag.IF:
            case '{':
                new_label=code.newLabel();
                stat(new_label);
                code.emitLabel(new_label); 
                statlistp(lnext_statlist);
                break;
            default:
                error("prog");
        }
    }

    public void statlistp(int lnext_statlistp){
        int new_label;
        switch(look.tag){
            case ';':
                match(';');
                new_label=code.newLabel();
                stat(new_label);
                code.emitLabel(new_label);
                statlistp(lnext_statlistp);
                break;
            case Tag.EOF:
            case '}':
                break;
            
            default:
                error("statlistp");
        }
    }
    
    public void stat(int lnext_stat) {
        int b_true,b_false;
        switch(look.tag) {
            case Tag.ASSIGN:
                match(Tag.ASSIGN);
                expr();
                match(Tag.TO);
                idlist(lnext_stat,0);//invio parametro 0 per control
                code.emit(OpCode.pop);//elimina dup extra
                code.emit(OpCode.GOto,lnext_stat);
                break;

            case Tag.PRINT:
                match(Tag.PRINT);
                match('(');
                exprlist(1);//invio parametro 1 per il control
                match(')');
                code.emit(OpCode.GOto,lnext_stat);
                break;

            case Tag.READ:
                match(Tag.READ);
                match('(');
                idlist(lnext_stat,1); //parametro 1 per il control
                match(')'); 
                code.emit(OpCode.GOto,lnext_stat);
                break;
                
            case Tag.WHILE:
                match(Tag.WHILE);
                int begin = code.newLabel(); //label per il loop
                match('(');
                code.emitLabel(begin);//inizio del loop
                b_true = code.newLabel();//label a cui andare per entrare nel ciclo (cond soddisfatta)
                bexpr(b_true);
                match(')');
                code.emit(OpCode.GOto, lnext_stat);//caso di condizione non soddisfatta, esco dal while
                code.emitLabel(b_true);
                stat(begin);
                code.emit(OpCode.GOto, begin);//richiamo begin
                break;

            case Tag.IF:
                match(Tag.IF);
                match('(');
                b_true= code.newLabel(); //preparo le label per ifcmp e goto
                b_false = code.newLabel();
                bexpr(b_true);
                match(')');
                code.emit(OpCode.GOto,b_false);//caso condizione non soddisfatta
                code.emitLabel(b_true);//ramo true
                stat(lnext_stat);
                code.emitLabel(b_false);//ramo false
                iffalse(lnext_stat);//metodo da me introdotto
                break;
            
            case '{':
                match('{');
                statlist(lnext_stat);
                match('}');
                break;

            
            default:
                error("stat");
        }
     }
     //metodo per i casi con e senza else
     public void iffalse(int lnext_false){
        switch(look.tag){
            case Tag.ELSE:
                match(Tag.ELSE);
                stat(lnext_false);
                match(Tag.END);
                break;
            case Tag.END:
                match(Tag.END);
                code.emit(OpCode.GOto,lnext_false);
                break;
            default:
                error("iffalse");
        }
     }

    private void idlist(int lnext_idlist,int control) {
        
        switch(look.tag) {
        case Tag.READ:
	    case Tag.ID:
            int id_addr = st.lookupAddress(((Word)look).lexeme);
            if (look.tag == Tag.ID && id_addr == -1) {
                    id_addr = count;
                    st.insert(((Word)look).lexeme,count++);
                }
        if(control==0){ //assign può essere di più elementi, quindi aggiungiamo dup per salvare lo stesso valore in più variabili
            code.emit(OpCode.dup);
            code.emit(OpCode.istore,id_addr);
        }
                
        else if (control==1){ //caso di read
            code.emit(OpCode.invokestatic,0);
            code.emit(OpCode.istore,id_addr);
        }
        match(Tag.ID);
        idlistp(lnext_idlist,control);
                break;
            default:
                error("idlist");
    	}
    }

    public void idlistp(int lnext_listp,int control){
        switch(look.tag){
            case ',':
                match(',');
                    int id_addr = st.lookupAddress(((Word)look).lexeme);
                    if (look.tag == Tag.ID && id_addr == -1) {
                            id_addr = count;
                            st.insert(((Word)look).lexeme,count++);
                        }
                if(control==0){
                    code.emit(OpCode.dup);
                    code.emit(OpCode.istore,id_addr);
                }
                        
                else if (control==1){
                    code.emit(OpCode.invokestatic,0);
                    code.emit(OpCode.istore,id_addr);
                }
                    
                
                match(Tag.ID);
                idlistp(lnext_listp,control);
                
                break;
            case ')':
            case ';':
            case Tag.END:
            case Tag.ELSE:
            case Tag.EOF:
            case '}':
                break;
            default:
                error("idlistp");
        }
    }

    	
    public void bexpr(int t){
        switch(look.tag){
            case Tag.RELOP:
                switch(((Word)look).lexeme){
                case "<":
                    match(Tag.RELOP);
                    expr();
                    expr();
                    code.emit(OpCode.if_icmplt,t);
                    break;
                case ">":
                    match(Tag.RELOP);
                    expr();
                    expr();
                    code.emit(OpCode.if_icmpgt,t);
                    break;
                case "<=":
                    match(Tag.RELOP);
                    expr();
                    expr();
                    code.emit(OpCode.if_icmple,t);
                    break;
                case ">=":
                    match(Tag.RELOP);
                    expr();
                    expr();
                    code.emit(OpCode.if_icmpge,t);
                    break;
               
                case "==":
                    match(Tag.RELOP);
                    expr();
                    expr();
                    code.emit(OpCode.if_icmpeq,t);
                    break;
                case "<>":
                    match(Tag.RELOP);
                    expr();
                    expr();
                    code.emit(OpCode.if_icmpne,t);
                    break;
                }
                break;
            default:
                error("bexpr");
        }
    }

    private void expr() {
        switch(look.tag) {
            case '+':
                match('+');
                match('(');
                exprlist(2); //chiamo exprlist con il parametro adeguato per il control
                match(')');
                break;
            case '-':
                match('-');
                expr();
                expr();
                code.emit(OpCode.isub);
                break;
            case '*':
                match('*');
                match('(');
                exprlist(3); //chiamo exprlist con il parametro adeguato per il control
                match(')');
                break;
            case '/':
                match('/');
                expr();
                expr();
                code.emit(OpCode.idiv);
                break;
            case Tag.NUM:
                code.emit(OpCode.ldc, ((NumberTok)look).lex);
                match(Tag.NUM);
                break;
            case Tag.ID:
                int id_addr = st.lookupAddress(((Word)look).lexeme);
                if (id_addr==-1) {
                    id_addr = count;
                    st.insert(((Word) look).lexeme, count++);
                }
                
                code.emit(OpCode.iload,id_addr);
                match(Tag.ID);
                break;
            default:
                error("expr");
        }
    }

    public void exprlist(int num){
        switch(look.tag){
            case '+':
            case '-':
            case '*':
            case '/':
            case Tag.NUM:
            case Tag.ID:
            
                expr();
                if (num == 1) {
                    code.emit(OpCode.invokestatic, 1);
                }
                exprlistp(num);
                break;
            default:
                error("exprlist");
        }
    }

    public void exprlistp(int num){ //tramite il parametro num possiamo indicare il tipo di istruzione
        switch(look.tag){
            case ',':
                match(',');
                expr();
                
                if(num ==1){
                    code.emit(OpCode.invokestatic, 1); //caso di stampa
                } 
                else if (num == 2) {
                    code.emit(OpCode.iadd); //caso di addizione
                } else if (num == 3) {
                    code.emit(OpCode.imul); //caso di moltiplicazione
                } else {
                    error("exprlistp");
                }
                exprlistp(num);
                break;
            case ')':
                break;

            default:
                error("exprlistp");
            
        }
    }
    public static void main(String[] args) {
        Lexer lex = new Lexer();
        String path = "esempio_semplice.lft"; //path di esempio
        try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            Translator tr = new Translator(lex, br);
            tr.prog();
            System.out.println("\nFile Output.j generato!");
            System.out.println(
                    "Digita 'java -jar jasmin.jar Output.j' per il file Output.class e 'java Output' per eseguirlo.\n");
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

