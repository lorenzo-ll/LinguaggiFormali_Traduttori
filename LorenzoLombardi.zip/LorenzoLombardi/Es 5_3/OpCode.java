public enum OpCode { 
    ldc,dup, imul, ineg, idiv, iadd, 
    isub, istore, ior, iand, iload,
    if_icmpeq, if_icmple, if_icmplt, if_icmpne, if_icmpge, 
    if_icmpgt, ifne, GOto, invokestatic, label,pop } //aggiunte dup e pop