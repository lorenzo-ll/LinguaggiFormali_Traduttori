public class Es1_2
{
    public static boolean scan(String s)
    {
	int state = 0;
	int i = 0;

	while (state >= 0 && i < s.length()) {
	    final char ch = s.charAt(i++);
        
	    switch (state) {
	    case 0:
		if (ch >= 'a' && ch <= 'z'|| ch>='A' && ch <='Z'){
			state = 1;
		}
		else if (ch == '_' )
		    state = 0;
		else
		    state = -1;
		break;

		case 1:
		if (ch >= 'a' && ch <= 'z'|| ch>='A' && ch <='Z' || ch >= '0' && ch <='9' || ch == '_'){
			state = 1;
			}
		else{
			state = -1;
		}
	    }
	}
	return state == 1;
    }

    public static void main(String[] args)
    {
	System.out.println(scan("x") ? "OK" : "NOPE");
	System.out.println(scan("flag1") ? "OK" : "NOPE");
	System.out.println(scan("abbb___aaa2") ? "OK" : "NOPE");
	System.out.println(scan("__nansu010__1919djdj1__") ? "OK" : "NOPE");
    System.out.println(scan("1234") ? "OK" : "NOPE");
    System.out.println(scan("22£2x") ? "OK" : "NOPE");
    System.out.println(scan("___") ? "OK" : "NOPE");
	System.out.println(scan("a2__") ? "OK" : "NOPE");
    System.out.println(scan("!__22_") ? "OK" : "NOPE");
	System.out.println(scan("DDD//_") ? "OK" : "NOPE");
    }
}