import java.io.*; 

public class Lexer {

    public static int line = 1;
    private char peek = ' ';
    
    private void readch(BufferedReader br) {
        try {
            peek = (char) br.read();
        } catch (IOException exc) {
            peek = (char) -1; // ERROR
        }
    }

    public Token lexical_scan(BufferedReader br) {
        while (peek == ' ' || peek == '\t' || peek == '\n'  || peek == '\r') {
            if (peek == '\n') line++;
            readch(br);
        }
        
        switch (peek) {
            case '!':
                peek = ' ';
                return Token.not;

            case '(':
                peek = ' ';
                return Token.lpt;

            case ')':
                peek = ' ';
                return Token.rpt;
            
            case '{':
                peek = ' ';
                return Token.lpg;

            case '}':
                peek = ' ';
                return Token.rpg;

            case '+':
                peek = ' ';
                return Token.plus;

            case '-':
                peek = ' ';
                return Token.minus;

            case '*':
                peek = ' ';
                return Token.mult;

            case '/':
                readch(br);
                if (peek=='/'){
                    while(peek!='\n'){
                        readch(br);
                    }
                }
                else if (peek=='*'){
                    boolean control=false;
                    while(control==false){
                        readch(br);
                        if (peek=='*'){
                            readch(br);
                            if (peek=='/'){
                                control=true;
                            }
                        }
                            
                    }
                }
                else{
                    peek = ' ';
                    return Token.div;
                }
                

            case ';':
                peek = ' ';
                return Token.semicolon;

            case ',':
                peek = ' ';
                return Token.comma;

	
            case '&':
                readch(br);
                if (peek == '&') {
                    peek = ' ';
                    return Word.and;
                } else {
                    System.err.println("Erroneous character"
                            + " after & : "  + peek );
                    return null;
                }
            case '|':
                readch(br);
                if (peek == '|') {
                    peek = ' ';
                    return Word.or;
                } else {
                    System.err.println("Erroneous character"
                            + " after & : "  + peek );
                    return null;
                }

            case '<':
                readch(br);
                if (peek == '=') {
                    peek = ' ';
                    return Word.le;
                } else if (peek == '>') {
                    peek = ' ';
                    return Word.ne;
                } 
                else {
                    peek=' ';
                    return Word.lt;
                }

            case '>':
                readch(br);
                if (peek == '=') {
                    peek = ' ';
                    return Word.ge;
                } else {
                    peek = ' ';
                    return Word.gt;
                }

            case '=':
                readch(br);
                if (peek == '=') {
                    peek = ' ';
                    return Word.eq;
                } else {
                    System.err.println("Erroneous character"
                            + " after & : "  + peek );
                    return null;
                }
            
          
            case (char)-1:
                return new Token(Tag.EOF);

            default:
                if (Character.isLetter(peek)) {
                    String s="";
                while (peek!=(char)-1 && Character.isLetter(peek)){
                    
                    s=s.concat(Character.toString(peek));
                    readch(br);
                }
                peek=' ';
                switch(s){
                    case "assign":
                        return new Word(Tag.ASSIGN,s);
                    case "to":
                        return new Word(Tag.TO,s);
                    case "if":
                        return new Word(Tag.IF,s);
                    case "else":
                        return new Word(Tag.ELSE,s);
                    case "while":
                        return new Word(Tag.WHILE,s);
                    case "begin":
                        return new Word(Tag.BEGIN,s);
                    case "end":
                        return new Word(Tag.END,s);
                    case "print":
                        return new Word(Tag.PRINT,s);
                    case "read":
                        return new Word(Tag.READ,s);
                    case "or":
                        return new Word(Tag.OR,s);
                    case "and":
                        return new Word(Tag.AND,s);
                    default:
                        return new Word(Tag.ID,s);
                    
                }


                } else if (Character.isDigit(peek)) {
                    int val=0;
                    while (peek!=(char)-1 && Character.isDigit(peek)){ 
                        
                        val=(val*10)+Character.getNumericValue(peek);
                        readch(br);
                        
                    }
                    peek=' ';
                    return new NumberTok(Tag.NUM,val);



                } else {
                        System.err.println("Erroneous character: " 
                                + peek );
                        return null;
                }
         }
    }
		
    public static void main(String[] args) {
        Lexer lex = new Lexer();
        String path = "Prova.txt "; // il percorso del file da leggere
        try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            Token tok;
            do {
                tok = lex.lexical_scan(br);
                System.out.println("Scan: " + tok);
            } while (tok.tag != Tag.EOF);
            br.close();
        } catch (IOException e) {e.printStackTrace();}    
    }

}
