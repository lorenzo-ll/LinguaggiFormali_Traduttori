public class NumberTok extends Token {
    int lex=0;
	public NumberTok(int tag, int value) { super(tag); lex=value; }
    public String toString() { return "<" + tag + ", " + lex + ">"; }
}
