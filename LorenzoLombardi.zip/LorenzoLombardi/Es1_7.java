public class Es1_7{
    public static boolean scan(String s)
    {
	int state = 0;
	int i = 0;

	while (state >= 0 && i < s.length()) {
	    final char ch = s.charAt(i++);

	    switch (state) {
		case 0:
		if (ch=='L')
			state=1;
		else
			state=11;
		break;

		case 1:
		if (ch=='o')
			state=2;
		else 
			state=12;
		break;

		case 2:
		if (ch=='r')
			state=3;
		else
			state=13;
		break;

		case 3:
		if (ch=='e')
			state=4;
		else
			state=14;
		break;

		case 4:
		if (ch=='n')
			state=5;
		else
			state=15;
		break;

		case 5:
		if (ch=='z')
			state=6;
		else
			state=16;
		break;

		case 11:
		if (ch=='o')
			state=12;
		else
			state=-1;
		break;

		case 12:
		if (ch=='r')
			state=13;
		else
			state=-1;
		break;

		case 13:
		if (ch=='e')
			state=14;
		else
			state=-1;
		break;

		case 14:
		if (ch=='n')
			state=15;
		else
			state=-1;
		break;

		case 15:
		if (ch=='z')
			state=16;
		else
			state=-1;
		break;

		case 16:
		if (ch=='o')
			state=17;
		else
			state=-1;
		break;
		}	
		}
		return state==6 || state==17;	
    }

    public static void main(String[] args)
    {
	System.out.println(scan("Lorenzo") ? "OK" : "NOPE");
    System.out.println(scan("Lowenzo") ? "OK" : "NOPE");
	System.out.println(scan("oorenzo") ? "OK" : "NOPE");
    System.out.println(scan("LorEnZo") ? "OK" : "NOPE");
	System.out.println(scan("Loreeeo") ? "OK" : "NOPE");
	System.out.println(scan("Lore%zo") ? "OK" : "NOPE");
	System.out.println(scan("Lo//nzo") ? "OK" : "NOPE");
    }
}